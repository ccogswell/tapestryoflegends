"""
D&D Roleplay Session Manager Bot

A Discord bot for managing D&D roleplay sessions with automatic
time tracking and reward distribution.
"""

__version__ = "1.0.0"
__author__ = "D&D Bot Developer"
